<?php
require_once("dbcon.php");
session_start();
if(!isset($_SESSION['name'])){
	header("location:index.php");
}
echo "welcome ".$_SESSION['name'];

?>
<br>
<a href="logout.php">Logout</a>