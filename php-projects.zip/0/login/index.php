<?php
require_once("dbcon.php");
session_start();
if(isset($_SESSION['name'])){
	header("location:dashboard.php");
}

if(isset($_POST['regester'])){
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$sql="insert into login(username,password) values('$user','$pass')";
	if($con->exec($sql)){
		echo "<b>User Regestered</b>";
	}
	else
	{
		echo "<b>User Regesteration fail</b>";
	}
	
}
else{
if(isset($_POST['login'])){
		$user=$_POST['user'];
	$pass=$_POST['pass'];
	$sql="select * from login where username='$user' and password='$pass'";
		$result=$con->query($sql);
	$row=$result->fetch(PDO::FETCH_ASSOC);
	if($result->rowcount()==1)
	{
		$_SESSION['name']=$user;
		header("location:dashboard.php");
	}		
	else	
		header("location:index.php");

}
}
?>
<html>
<head>
	<title>Login System</title>
</head>
<body>
<a href="../">Home</a><br>
<br>
<p id="msg"></p>
<form action="" method="post">
<table border="1">
	<tr>
	<th colspan="2">Regestration</th>
	</tr>
	<tr>
	<td>UserName</td>
	<td><input type="text" name="user" placeholder="create username "></td>
	</tr>
	
	<tr>
	<td>Password</td>
	<td><input type="password" name="pass" placeholder="create password"></td>
	</tr>
	
	<tr>
		<td colspan="2"><input type="submit" value="Regester" name="regester"></td>
	</tr>
</table>
</form>
<hr>
<form action="" method="post">
<table border="1">
	<tr>
	<th colspan="2">Login</th>
	</tr>
	<tr>
	<td>UserName</td>
	<td><input type="text" name="user" placeholder="username "></td>
	</tr>
	
	<tr>
	<td>Password</td>
	<td><input type="password" name="pass" placeholder="password"></td>
	</tr>
	
	<tr>
		<td colspan="2"><input type="submit" value="Login" name="login"></td>
	</tr>
</table>
</form>
<body>
</html>