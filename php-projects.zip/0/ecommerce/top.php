<?php
require_once('connection.php');
require_once('functions.inc.php');
$sql="select * from categories where status=1 order by categories asc";
$result=mysqli_query($con,$sql);
$cat=array();
while($row=mysqli_fetch_assoc($result))
{
	$cat[]=$row;
}
?>
<html>
	<head>
		<title>Home Page</title>
		<script>
		#left {
    border: 2px solid blue;
    position: absolute;
    left: 0px;
    top: 0px;
    bottom: 0px;
    width: 25%;
}

#right {
    border: 2px solid blue;
    position: absolute;
    right: 0px;
    top: 0px;
    bottom: 0px;
    width: 25%;
}

#center {
    border: 2px solid red;
    position: absolute;
    right: 25%;
    top: 0px;
    bottom: 0px;
    width: 50%;
}</script>
	</head>
<body>
<h1>Vishnu Kumar Bhardwaj (E-commerce Project)</h1>
<a href="index.php">Home</a>

<?php
	foreach($cat as $list){
		?>
	<a href="categories.php?id=<?php echo $list['id']?>"><?php echo $list['categories']; ?></a>
<?php 
	}
?>
<a href="contactus.php">Contact Us</a>
<a href="login.php">Login/Regester</a>
