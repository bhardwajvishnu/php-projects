<?php
require('../dbcon/dbcon.php');	// database connection include;
session_start();	// session start;
if(!isset($_SESSION['name'])){		//verify admin
		header('location:index.php');
}
echo "welcome ".$_SESSION['name'];	// print welcome message
$edit='';
$msg='';
if(isset($_GET['type']) && $_GET['type']!=" "){		// change status
	$type=$_GET['type'];	
	if($type=='status'){
		$operation=$_GET['operation'];
		$id=$_GET['id'];
		if($operation=="active")
			$status='1';
		else	
			$status='0';
		$update_status="update categories set status='$status' where id='$id'";
		$con->exec($update_status);
	}
	if($type=='delete'){
		 $id=$_GET['id'];
		 $sql="delete from categories where id='$id' ";
		 $con->exec($sql);
		 
	}
}													// status if condition closed


// add new category condition starts from here
if(isset($_POST['addcat'])){						// add new category
	$name=$_POST['category'];
	$sql="select categories from categories where categories ='$name'";
	$result=$con->query($sql);
	if($result->rowcount()>0){
		$msg="categories already exists";
	}
	else{
	$sql="insert into categories(categories,status) values('$name',1)";
	$con->exec($sql);
	}
}






// edit category
if(isset($_GET['edit'])){
	$id=$_GET['edit'];
	$sql="select * from categories where id=$id";
	$result1=$con->query($sql);
	$editrow=$result1->fetch(PDO::FETCH_ASSOC);
	if($id!=$editrow['id']  ){
		header('location:index.php');
		die();
	}
	$oldname=$editrow['categories'];
	if(isset($_POST['submit1']))
	{
		$newname=$_POST['editcategory'];
		$sql="update categories set categories='$newname' where id=$id";
		$con->exec($sql);
		header('location:index.php');
		
	}
}

$sql="select * from categories order by categories";
$result=$con->query($sql);
 
?>

<html>
<head>
	<title>Categories</title>
<head>
<body>
<div id="cat" style="background-color:silver; width:220px; border-radius:20px">
	<ol type="1">
	<li><a href="categories.php">Categories Master</a></li>
	<li style=""><a href="product.php">Product Master</a></li>
	<li><a href="users.php">User Master</a></li>
	<li><a href="contactus.php">contact us</a></li>
	</ol>
</div
<div align="right"><a href="logout.php">Logout</a></div><br><br>

<!--	add category form only     -->
<form action="" method="post">

	<table border="1">
	<tr>
		<th colspan="2">Categories Form</th>
	</tr>
	
	<tr>
		<td>Category Name : <input type="text" name="category" required>&nbsp;&nbsp;&nbsp;
		<input type="submit" name="addcat" value="Add New Category"></td>
	</tr>
	</table>
	</form>
	
	
<!--	Updatecategory      -->
<?php
if(isset($_GET['edit'])){
?>
<form action="" method="post">
	<table border="1">
	<tr>
		<th colspan="2">Edit Category</th>
	</tr>
	
	<tr>
		<td>Category Name : <input type="text" name="editcategory" value="<?php echo $oldname; ?>" required>
		&nbsp;&nbsp;&nbsp;
		<input type="submit" name="submit1" value="Edit Category"></td>
	</tr> 
	</table>
	</form>

<?php
}
?>

<!-- List of Categories -->
<?php echo "$msg"; ?>
<table border="1" width="80%" style="text-align:center">
<tr>	
	<th>Serial</th>
	<th>Category</th>
	<th>Status</th>
</tr>
<?php
if($result->rowcount()>0){
	$i=1;
	while($row=$result->fetch(PDO::FETCH_ASSOC)){
			echo "<tr >";
					echo "<td> $i</td>";
					echo "<td>".$row['categories']."</td>";
					echo "<td >";
					if($row['status']==1)
							echo "<a href='?type=status&operation=deactive&id={$row['id']}'style='color:green;text-decoration:none'>Active </a>&nbsp;&nbsp;&nbsp;&nbsp;";
					else
							echo "<a href='?type=status&operation=active&id={$row['id']}' style='color:red; text-decoration:none'>Deactive</a>&nbsp;&nbsp;&nbsp;&nbsp;";
					
							echo "<a href='?type=delete&operation=active&id={$row['id']}'>Delete</a>&nbsp;&nbsp;&nbsp;&nbsp;";
							echo "<a href='?edit={$row['id']}'>Edit</a>";
					
					echo "</td>";
			echo "</tr>";
			$i++;
	}
	
}
?>
</table>
<br><br>
Copyright &copy <?php echo date('Y'); ?>
</body>
</html>