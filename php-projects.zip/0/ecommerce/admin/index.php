<?php
require_once('../dbcon/dbcon.php');
session_start();
if(isset($_SESSION['name'])){
		header('location:categories.php');
}
$msg='';
if(isset($_POST['login'])){
	$user=$_POST['user'];
	$pass=$_POST['pass'];
//	$u=mysqli_real_escape_string($con,$user);
//	$p=mysqli_real_escape_string($con,$pass);
	$sql="select * from admin_users where username='$user' and password='$pass'";
	$result=$con->query($sql);
	if($result->rowcount()==1){
		$_SESSION['name']='admin';
		header('location:categories.php');
		die();
	}
	else
	{
		$msg="username or password is incorrect";
		
	}
	
}
?><html>
	<head>
		<title>E-commerce</title>
	</head>
<body>
	<a href="../">Home</a>
	<br><center>
	
<form action="" method="post">
<table border="1">
	<tr>
	<th colspan="2">Login</th>
	</tr>
	<tr>
	<td>UserName</td>
	<td><input type="text" name="user" placeholder="username "></td>
	</tr>
	
	<tr>
	<td>Password</td>
	<td><input type="password" name="pass" placeholder="password"></td>
	</tr>
	
	<tr>
		<td colspan="2"><input type="submit" value="Login" name="login"></td>
	</tr>
</table>
</form>
<?php echo $msg?>
</body>
</html>