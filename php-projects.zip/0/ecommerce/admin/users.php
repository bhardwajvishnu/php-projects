<?php
require('../dbcon/dbcon.php');	// database connection include;
session_start();	// session start;
if(!isset($_SESSION['name'])){		//verify admin
		header('location:index.php');
}if(isset($_GET['type']) && $_GET['type']!=" "){		// change status
	$type=$_GET['type'];
	if($type=='delete'){
		 $id=$_GET['id'];
		 $sql="delete from users where id='$id' ";
		 $con->exec($sql);
		 
	}
}

echo "welcome ".$_SESSION['name'];	// print welcome message
$sql="select * from users order by id desc";
$result=$con->query($sql);



?>
<html>
<head>
	<title>Categories</title>
<head>
<body>
<div id="cat" style="background-color:silver; width:220px; border-radius:20px">
	<ol type="1">
	<li><a href="categories.php">Categories Master</a></li>
	<li style=""><a href="product.php">Product Master</a></li>
	<li><a href="users.php">User Master</a></li>
	<li><a href="contactus.php">contact us</a></li>
	</ol>
</div
<div align="right"><a href="logout.php">Logout</a></div><br><br>
<form action="" method="post">
<table border="1" width="100%" style="text-align:center">
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Email</th>
		<th>Mobile</th>
		<th>Password</th>
	
		<th>Date</th>
		<th>Delete Data</th>
	</tr>
<?php
if($result->rowcount()>0){
	
		while($row=$result->fetch(PDO::FETCH_ASSOC)){
				echo "<tr><td>{$row['id']}</td>
		<td>{$row['name']}</td>
		<td>{$row['mobile']}</td>
		<td>{$row['email']}</td>
		<td>{$row['password']}</td>

		<td>{$row['added_on']}</td>
		<td><a href='?type=delete&id={$row['id']}'>Delete</a></td>
		
	</tr>";
		}
	
}
	
?>

</table>
</form>
</body>
</html>