<?php
require('../dbcon/dbcon.php');	// database connection include;
session_start();	// session start;
if(!isset($_SESSION['name'])){		//verify admin
		header('location:index.php');
}
echo "welcome ".$_SESSION['name'];	// print welcome message

// default variables set;
$categories_id="";
$name="";
$mrp="";
$price="";
$qty="";
$image="";
$shortdes="";
$description="";
$meta_title="";
$meta_des="";
$meta_keyword="";
//$status="";





$edit='';
$msg='';
if(isset($_GET['type']) && $_GET['type']!=" "){		// change status
	$type=$_GET['type'];	
	if($type=='status'){
		$operation=$_GET['operation'];
		$id=$_GET['id'];
		if($operation=="active")
			$status='1';
		else	 
			$status='0';
		$update_status="update product set status='$status' where id='$id'";
		$con->exec($update_status);
	}
	if($type=='delete'){
		 $id=$_GET['id'];
		 $sql="delete from product where id='$id' ";
		 $con->exec($sql);
		 
	}
}													// status if condition closed


// add new category condition starts from here
if(isset($_POST['addpro'])){						// add new p
	$name=$_POST['name'];
	$categories_id=$_POST['categories_id'];
	
	$mrp=$_POST['mrp'];
	$price=$_POST['price'];
	$qty=$_POST['qty'];
	$image=$_FILES['image']['name'];
	$shortdes=$_POST['shortdes'];
	$description=$_POST['description'];
	$meta_title=$_POST['meta_title'];
	$meta_des=$_POST['meta_des'];
	$meta_keyword=$_POST['meta_keyword'];
	
	$sql="select name from product where name ='$name'";
	$result=$con->query($sql);
	if($result->rowcount()>0){
		$msg="product already exists";
	}
/*	else{
		if($_FILES['image']['type']!="" || ($_FILES['image']['type']!="image/png") || $_FILES['image']['type']!="image/jpg" || $_FILES['image']['type']!="image/jped"){
	$msg="please select only jpeg/png image formate";
	}*/
	else{
		$image=rand(1111,9999).'_'.$_FILES['image']['name'];
		
		move_uploaded_file($_FILES['image']['tmp_name'],'../media/product/'.$image);
	$sql="insert into product (name,categories_id,mrp,price,qty,shortdes,description,meta_title,meta_des,meta_keyword,status,image)
	values('$name','$categories_id',$mrp,$price,$qty,'$shortdes','$description','$meta_title','$meta_des','$meta_keyword',1,'$image');";
	$con->exec($sql);
	header('location:product.php');
	die();
//	}
	}
}






// edit category
if(isset($_GET['edit'])){
	$id=$_GET['edit'];
	$sql="select * from product where id=$id";
	$result1=$con->query($sql);
	$editrow=$result1->fetch(PDO::FETCH_ASSOC);
	if($id!=$editrow['id']  ){
		header('location:index.php');
		die();
	}
	$oldname=$editrow['name'];
	if(isset($_POST['submit1']))
	{
		$newname=$_POST['editcategory'];
		$sql="update product set name='$newname' where id=$id";
		$con->exec($sql);
		header('location:product.php');
		
	}
}

//list of all product
$sql="select product.*, categories.categories from product,categories where product.categories_id=categories.id  order by product.id desc";
$result=$con->query($sql);
 
?>

<html>
<head>
	<title>Product Master</title>
<head>
<body>
<div id="cat" style="background-color:silver; width:220px; border-radius:20px">
	<ol type="1">
	<li><a href="categories.php">Categories Master</a></li>
	<li style=""><a href="product.php">Product Master</a></li>
	<li><a href="users.php">User Master</a></li>
	<li><a href="contactus.php">contact us</a></li>
	</ol>
</div
<div align="right"><a href="logout.php">Logout</a></div><br><br>

<!--	add category form only     -->
<form action="" method="post" enctype="multipart/form-data">

	<table border="1">
	<tr>
		<th colspan="2">Add Products</th>
	</tr>
	
	<tr>
		<td>Select Category :
			<select  name="categories_id" required>	
				<?php
				$q="select id, categories from categories order by categories asc";
				$res=$con->query($q);
				while($row=$res->fetch(PDO::FETCH_ASSOC)){
					echo "<option value='{$row['id']}'>{$row['categories']}</option>";
						echo "x";
				}
						?>
			</select>
		</td>
	
		<td>Product Name : <input type="text" name="name" value="<?php echo $name ?>" required></td>
		<td>Mrp<input type="text" name="mrp" value="<?php echo $mrp ?>" placeholder="enter mrp" required></td>
		<td>Price<input type="text" name="price" value="<?php echo $price ?>" placeholder="enter price" required></td>
		<td>Qty<input type="text" name="qty" value="<?php echo $qty ?>" placeholder="enter qty" required></td>
	</tr>
	<tr>
	
		<td>Image<input type="File" name="image" required></td>
		<td>Short Description<textarea name="shortdes" value="<?php echo $shortdes ?>" required></textarea></td>

		<td> Description<textarea name="description" value="<?php echo $description ?>" required></textarea></td>
		<td>Meta Title<textarea name="meta_title" value="<?php echo $meta_title ?>"></textarea></td>
		<td>Meta Description<textarea name="meta_des" value="<?php echo $meta_des ?>"></textarea></td>
		<td>Meta Keyword<textarea name="meta_keyword" value="<?php echo $meta_keyword ?>"></textarea></td>
	</tr>
	
	
	<tr>
	<td><input type="submit" name="addpro" value="Add Product"></td>
	</tr>
	</table>
	</form>
	
	
<!--	Updatecategory      -->
<?php
if(isset($_GET['edit'])){
?>
<form action="" method="post">
	<table border="1">
	<tr>
		<th colspan="2">Edit Product</th>
	</tr>
	
	<tr>
		<td>Product Name : <input type="text" name="editcategory" value="<?php echo $oldname; ?>" required>
		&nbsp;&nbsp;&nbsp;
		<input type="submit" name="submit1" value="Edit Product"></td>
	</tr> 
	
	</table>
	</form>

<?php
}
?>

<!-- List of Categories -->
<?php echo " $msg<br><br>"; ?>
<table border="1" width="80%" style="text-align:center">
<tr>	
	<th>Serial</th>
	<th>Categories</th>
	<th>Name</th>
	<th>Image</th>
	<th>Mrp</th>
	<th>Price</th>
	<th>Qty</th>
</tr>
<?php
if($result->rowcount()>0){
	$i=1;
	while($row=$result->fetch(PDO::FETCH_ASSOC)){
			echo "<tr >";
					echo "<td> $i</td>";
				//	echo "<td>".$row['id']."</td>";
					echo "<td>".$row['categories']."</td>";
					echo "<td>".$row['name']."</td>";
	echo "<td><img src='../media/product/{$row['image']}' style='width:100px' height:100px'></td>";
					echo "<td>".$row['mrp']."</td>";
					echo "<td>".$row['price']."</td>";
					echo "<td>".$row['qty']."</td>";
				echo "<td >";
					if($row['status']==1)
							echo "<a href='?type=status&operation=deactive&id={$row['id']}'style='color:green;text-decoration:none'>Active </a>&nbsp;&nbsp;&nbsp;&nbsp;";
					else
							echo "<a href='?type=status&operation=active&id={$row['id']}' style='color:red; text-decoration:none'>Deactive</a>&nbsp;&nbsp;&nbsp;&nbsp;";
					
							echo "<a href='?type=delete&operation=active&id={$row['id']}'>Delete</a>&nbsp;&nbsp;&nbsp;&nbsp;";
							echo "<a href='?edit={$row['id']}'>Edit</a>";
					
					echo "</td>";
			echo "</tr>";
			$i++;
	}
	
}
?>
</table>
<br><br>
Copyright &copy <?php echo date('Y'); ?>
</body>
</html>