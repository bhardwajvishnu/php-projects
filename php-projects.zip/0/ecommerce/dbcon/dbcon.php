<?php
$con=new pdo("mysql:host=localhost;dbname=ecom","root","");
?>