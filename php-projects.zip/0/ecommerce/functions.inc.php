<?php
require_once('connection.php');
function get_product($con ,$type="" ,$limit=""){
$sql="select * from product where status=1";
if($type=="latest"){
		$sql.=" order by id desc";
	}
if($limit!=""){
		$sql.=" limit $limit";
	}
$data=array();


$result=mysqli_query($con,$sql);

while($row=mysqli_fetch_assoc($result))
{
	$data[]=$row;
}
		return $data;
}
?> 