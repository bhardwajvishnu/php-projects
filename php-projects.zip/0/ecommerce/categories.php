<?php
require_once('connection.php');
require_once('top.php');

require_once('footer.php');

$get_product=get_product($con,'latest',2);


foreach($get_product as $list){
?>
<div id="left" style="background-color:white; color:black; height=50%; width=50%" />
<a href="product.php?id=<?php echo $list['id']?>">
<h1>Name: <?php echo $list['name']; ?></h1></a>

<h2>Mrp: <?php echo $list['mrp']; ?></h2>
<h3>Price: <?php echo $list['price']; ?></h3>
<img src="media/product/<?php echo "{$list['image']}" ?>" style="height:120px "></img>
</div>
