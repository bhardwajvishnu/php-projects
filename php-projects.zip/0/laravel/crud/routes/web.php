<?php

use Illuminate\Support\Facades\Route;
use App\http\controllers\crudcontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::view('insert','insert');
			
			Route::view('login','admin.login');



Route::post('insert',[crudcontroller::class,'insert']);
Route::get('list',[crudcontroller::class,'list']);
Route::get('update',[crudcontroller::class,'showdata']);
Route::get('update/{id}',[crudcontroller::class,'update_form']);
Route::post('update/edit',[crudcontroller::class,'updated']);
Route::get('delete/',[crudcontroller::class,'del']);
Route::get('drop/{id}',[crudcontroller::class,'drop']);


//login function starts from here
Route::post('login',[checklogin::class,'check']);
