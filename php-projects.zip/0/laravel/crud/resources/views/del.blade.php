<html>
	<head>
		<title>Crud Operation Project </title>
	</head>
	<body>
		<a href="/">Home</a>
		<h1><center>Delete Data</center></h1>
@if(session('msg'))
	<h1>{{session('msg')}}</h1>
	
@endif
	<form action="insert" method="post">
	@csrf
	<table border="1" width="100%" style="text-align:center">
		<tr>
		<th>Serial</th>
		<th>Name</th>
		<th>Father Name</th>
		<th>Mother Name</th>
		<th>Mobile</th>		
		<th>Email</th>
		<th>Address</th>
		<th>Text</th>
		<th>Delete</th>
		</tr>
		
@foreach($list as $a)
		<tr>
		<td>{{$a['id']}}</td>
		<td>{{$a['name']}}</td>
		<td>{{$a['father']}}</td>
		<td>{{$a['mother']}}</td>
		<td>{{$a['email']}}</td>
		<td>{{$a['mobile']}}</td>		
		<td>{{$a['address']}}</td>
		<td>{{$a['text']}}</td>
		<td><a href="drop/{{$a['id']}}">Delete</td>
		</tr>
@endforeach

	</table>


	</form>
	</body>
</html>