<html>
	<head>
		<title>Crud Operation Project </title>
	</head>
	<body>
		<a href="/">Home</a>
		<h1><center>Insert Data into Database</center></h1>
	
	@if(session('msg'))
	<h1>data saved</h1>{{session('msg')}}
<h2>your name is : {{session('user')}}</h2>
	@endif
	
<form action="insert" method="post">
	@csrf
	<table border="1" width="100%" style="text-align:center">
		<tr>
		<th>Name</th>
		<th>Father Name</th>
		<th>Mother Name</th>
		<th>Mobile</th>		
		<th>Email</th>
		<th>Address</th>
		<th>Text</th>
		</tr>
		
		<tr>
		<td><input type="text" name="name" required></td>
		<td><input type="text" name="fname" required></td>
		<td><input type="text" name="mname" required></td>
		<td><input type="text" name="mobile" required></td>		
		<td><input type="text" name="email" required></td>
		<td><input type="text" name="address" required></td>
		<td><input type="text" name="text" required></td>
		</tr>
		<tr>
		
		<td colspan="7"><input type="submit" value="insert data" name="submit" style="width:100%"></td>
		</tr>
	</table>
	</form>
	</body>
</html>