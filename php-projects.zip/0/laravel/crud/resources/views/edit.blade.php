<html>
	<head>
		<title>Crud Operation Project </title>
	</head>
	<body>
		<a href="/">Home</a>
		<h1><center>Update Details</center></h1>
	
	<form action="edit" method="post">
	@csrf
	<input type="hidden" name="id" value="{{$list['id']}}" >
	<table border="1" width="100%" style="text-align:center">
		<tr>
		<th>Serial</th>
		<th>Name</th>
		<th>Father Name</th>
		<th>Mother Name</th>
		<th>Mobile</th>		
		<th>Email</th>
		<th>Address</th>
		<th>Text</th>
	
		</tr>
		

		<td><input type="text" name="name" value="{{$list['name']}}"></td>
		<td><input type="text" name="father" value="{{$list['father']}}"></td>
		<td><input type="text" name="mother" value="{{$list['mother']}}"></td>
		<td><input type="text" name="mobile" value="{{$list['email']}}"></td>
		<td><input type="text" name="email" value="{{$list['mobile']}}"></td>
		<td><input type="text" name="address" value="{{$list['address']}}"></td>		
		<td><input type="text" name="text" value="{{$list['text']}}"></td>
	
		<td><input type="submit" value="update" name="upd">
		
</tr>
	</table>
	</form>
	</body>
</html>