<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\details;

class crudcontroller extends Controller
{
    function insert(Request $r){
		$c=new details;
		$c->name=$r->name;
		$c->father=$r->fname;
		$c->mother=$r->mname;
		$c->mobile=$r->mobile;
		$c->email=$r->email;
		$c->address=$r->address;
		$c->text=$r->text;
		$c->save();
		$r->session()->flash('msg',"data has been inserted...");
		$r->session()->put('user',$r->name);
		return redirect('insert');		
	}
	
	function list(){
		$d=new details;
		$data=$d::all();
		return view('list',['list'=>$data]);
	}
	
	function showdata($del=NULL){
		$d=new details;
		$data=$d::all();
		return view('update',['list'=>$data]);
	}
	
	function update_form($id){
		$d=new details;
		$data=$d::find($id);
		return view('edit',['list'=>$data]);
	}
	
	function updated(Request $req){
		$d=new details;
		$d=$d::find($req->id);
		$d->name=$req->name;
		$d->father=$req->father;
		$d->mother=$req->mother;
		$d->email=$req->email;
		$d->mobile=$req->mobile;
		$d->address=$req->address;
		$d->text=$req->text;
		$d->save();
		$req->session()->flash('msg',"User's Data has been updated");
		return	 redirect('update');
	}
	
	
	function del(){
		$d=new details;
		$data=$d::all();
		return view('del',['list'=>$data]);
	}
	
	
	function drop(Request $req){
		$d=new details;
		$d=$d::find($req->id);
		$d->delete();
		$req->session()->flash('msg','Record Deleted...');
		return redirect('delete');
		
	}
	
	function delete($name){
		$data=details::find($name);
		$data->delete();
		return redirect('del');
	}
	
	
	
}
