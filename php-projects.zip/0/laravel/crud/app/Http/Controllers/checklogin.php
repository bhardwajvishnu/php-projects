<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\login;

class checklogin extends Controller
{
    //
}
