<html>
	<head>
		<title>Crud Operation Project </title>
	</head>
	<body>
		<h1><center>Crud Operation Project on Laravel</center></h1>
	<table border="1" width="100%" style="text-align:center">
		<tr>
		<th colspan="4">Select Options</th>
		</tr>
		<tr>
			<td><a href="insert">Insert Data</a></td>			
			<td><a href="list">View Data</a></td>
			<td><a href="update">Update Data</a></td>
			<td><a href="delete">Delete Data</a></td>
		</tr>
	</table>
	</body>
</html><?php /**PATH C:\xampp\htdocs\php\laravel\crud\resources\views/welcome.blade.php ENDPATH**/ ?>