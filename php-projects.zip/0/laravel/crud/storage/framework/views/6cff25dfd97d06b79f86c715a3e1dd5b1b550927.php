<html>
	<head>
		<title>Crud Operation Project </title>
	</head>
	<body>
		<a href="/">Home</a>
		<h1><center>Update Details</center></h1>
	
	<form action="edit" method="post">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="id" value="<?php echo e($list['id']); ?>" >
	<table border="1" width="100%" style="text-align:center">
		<tr>
		<th>Serial</th>
		<th>Name</th>
		<th>Father Name</th>
		<th>Mother Name</th>
		<th>Mobile</th>		
		<th>Email</th>
		<th>Address</th>
		<th>Text</th>
	
		</tr>
		

		<td><input type="text" name="name" value="<?php echo e($list['name']); ?>"></td>
		<td><input type="text" name="father" value="<?php echo e($list['father']); ?>"></td>
		<td><input type="text" name="mother" value="<?php echo e($list['mother']); ?>"></td>
		<td><input type="text" name="mobile" value="<?php echo e($list['email']); ?>"></td>
		<td><input type="text" name="email" value="<?php echo e($list['mobile']); ?>"></td>
		<td><input type="text" name="address" value="<?php echo e($list['address']); ?>"></td>		
		<td><input type="text" name="text" value="<?php echo e($list['text']); ?>"></td>
	
		<td><input type="submit" value="update" name="upd">
		
</tr>
	</table>
	</form>
	</body>
</html><?php /**PATH C:\xampp\htdocs\php\laravel\crud\resources\views/edit.blade.php ENDPATH**/ ?>