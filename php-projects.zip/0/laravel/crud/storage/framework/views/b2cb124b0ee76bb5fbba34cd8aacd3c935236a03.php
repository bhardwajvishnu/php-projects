<html>
	<head>
		<title>Crud Operation Project </title>
	</head>
	<body>
		<a href="/">Home</a>
		<h1><center>Delete Data</center></h1>
<?php if(session('msg')): ?>
	<h1><?php echo e(session('msg')); ?></h1>
	
<?php endif; ?>
	<form action="insert" method="post">
	<?php echo csrf_field(); ?>
	<table border="1" width="100%" style="text-align:center">
		<tr>
		<th>Serial</th>
		<th>Name</th>
		<th>Father Name</th>
		<th>Mother Name</th>
		<th>Mobile</th>		
		<th>Email</th>
		<th>Address</th>
		<th>Text</th>
		<th>Delete</th>
		</tr>
		
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		<td><?php echo e($a['id']); ?></td>
		<td><?php echo e($a['name']); ?></td>
		<td><?php echo e($a['father']); ?></td>
		<td><?php echo e($a['mother']); ?></td>
		<td><?php echo e($a['email']); ?></td>
		<td><?php echo e($a['mobile']); ?></td>		
		<td><?php echo e($a['address']); ?></td>
		<td><?php echo e($a['text']); ?></td>
		<td><a href="drop/<?php echo e($a['id']); ?>">Delete</td>
		</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>


	</form>
	</body>
</html><?php /**PATH C:\xampp\htdocs\php\laravel\crud\resources\views/del.blade.php ENDPATH**/ ?>