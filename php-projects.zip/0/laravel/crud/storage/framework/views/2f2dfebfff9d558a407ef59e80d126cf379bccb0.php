<html>
	<head>
		<title>Login Page</title>
	</head>
<body>
	<center>login page
	<form action="" method="post">
	<?php echo csrf_field(); ?>
	<table border="1">
		<tr>
		<th>Username</th>
		<td><input type="text" name="username" required></td>
		</tr>
		
		<tr>
			<th>password</th>
			<td><input type="password" name="pass" required></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" value="LogIn" name="login"></td>
		</tr>
	</table>
	</form>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\php\laravel\crud\resources\views/admin/login.blade.php ENDPATH**/ ?>