<?php


function clock(int $s){
	$hour=$minute=$second=0;
	$second=$s;
	$minute=$second/60;
	$minute=round($minute);
	
	echo "second : $second<br>";
	echo " mintue is : $minute";
/*	$minute=round($minute,0);
	$hour=$minute/60;
	$minute=$minute%60;
	$minute=round($minute,0);
	$second=$second%60;

	echo "<br> time is $hour:$minute:$second";
	}
	*/
	}
if(isset($_POST['clock'])){
	$second=$_POST['clock'];
	
	clock($second);
	
}
?>
<html>
<head>
<title>clock project
</title>
</head>
<body>
	<form action="" method="post">
	<input type="text" name="clock" placeholder="enter seconds">
	<input type="submit" value="get time">
	</form>
</body>
</html>