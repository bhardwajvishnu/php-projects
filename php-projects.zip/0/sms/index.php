<?php
require_once('dbcon/dbcon.php');
session_start();
if(isset($_SESSION['name'])){
	header('location:dashboard.php');
}
$msg="";
$msg1="";
if(isset($_POST['regester'])){
	$name=$_POST['name'];
	$fname=$_POST['fname'];
	$age=$_POST['age'];
	$mobile=$_POST['mob'];
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$pic=$_FILES['pic']['name'];
	$username=$name.rand(1111,9999);
	$ex="select * from sms where name='$name' and father='$fname'";
	$result=$con->query($ex);
	$row=$result->fetch(PDO::FETCH_ASSOC);
	if($row['name']==$name && $row['father']==$fname)
	{
		$msg="<h2>user has been regestered already<h2>";
	}
	else
	{	
	move_uploaded_file($_FILES['pic']['tmp_name'],"upload/".$pic);
	$sql="insert into sms(name,father,age,mobile,email,password,username,image) values('$name','$fname','$age','$mobile','$email','$pass','$username','$pic');";
	if($con->exec($sql)){
		$msg="<h3>student has been regestered and your username is $username<h3>";
	}
	}
}

if(isset($_POST['login'])){
	$username=$_POST['name'];
	$pass=$_POST['pass'];
	$sql="select * from sms where username='$username' and password='$pass'";
	$result=$con->query($sql);
	$row=$result->fetch(PDO::FETCH_ASSOC);
	$name=$row['name'];
	$user=$row['username'];
	if($result->rowcount()==1){
		$_SESSION['name']=$name;
		$_SESSION['uname']=$user;
		

		header('location:dashboard.php');
	}
	else	
		$msg1="Please enter correct username or password";
	

}

?>
<html>
	<head>
		<title>Student Management System</title>
	</head>
<body>
<a href="admin/">Admin Login</a><br><br>
<form action="" method="post" enctype="multipart/form-data">
<?php echo $msg; ?>
	<table border="1">
	<tr>
	<th colspan="2">Student Regester</th>
	</tr>

	<tr>
	 <td>Name:</td>
	<td><input type="text" name="name" required></td>
	</tr>
	
	<tr>
	 <td>Father:</td>
	<td><input type="text" name="fname" required></td>
	</tr>
	
	<tr>
	 <td>Age:</td>
	<td><input type="text" name="age" required></td>
	</tr>
	
	<tr>
	 <td>Mobile:</td>
	<td><input type="text" name="mob" required></td>
	</tr>
	
	<tr>
	 <td>email:</td>
	<td><input type="text" name="email"></td>
	</tr>
	
	<tr>
	 <td>Create Password:</td>
	<td><input type="password" name="pass"></td>
	</tr>
	
	<tr>
	 <td>Upload Image:</td>
	<td><input type="file" name="pic"></td>
	</tr>
	
	<tr>
		<td colspan="2"><input type="submit" name="regester" value="Regester Student"></td>
	</tr>
	</table>
</form>
<hr>
<form action="" method="post">
<?php echo $msg1; ?>
	<table border="1">
	<tr>
	<th colspan="2">Student Login</th>
	</tr>
	
	<tr>
	 <td>userName:</td>
	<td><input type="text" name="name" required></td>
	</tr>
	
	<tr>
	 <td>Password:</td>
	<td><input type="password" name="pass" required></td>
	</tr>
	<tr>
	
	<td><input type="submit" name="login" required></td>
	</tr>
	</table>
</form>
</body>
</html>