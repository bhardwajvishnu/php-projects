<?php
require_once('dbcon/dbcon.php');
session_start();
if(!isset($_SESSION['name'])){
	header('location:index.php');
}
$username=$_GET['username'];
$status="";
if(isset($_POST['changepass'])){
$n=$_POST['newpass'];
$c=$_POST['cpass'];

if($n==$c){
	$sql="update sms set password='$n' where username='$username'";
	if($con->exec($sql)){
	$status= "password changed";
	}
}
else	
{
	$status=	 "password does not match";
}
}


?>
<html>
	<head>
		<title>change password</title>
	</head>
<body>
<a href="dashboard.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href='logout.php'>Logout</a>
	<form action="" method="post">
	<?php echo "<br>".$status."<br>"; ?>
	new password :<input type="password" name="newpass" required><br>
	confirm password : <input type="password" name="cpass" required><br>
	<input type="submit" name="changepass" value="change password" name="submit">
	</form>
</body>
</html>