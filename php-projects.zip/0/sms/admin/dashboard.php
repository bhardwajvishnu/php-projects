<?php
require_once('../dbcon/dbcon.php');
session_start();
$msg_name="";
$msg_father="";
$msg_date="";
$sql="select * from sms order by name asc;";
$result=$con->query($sql);
if(isset($_GET['logout'])){
	session_destroy();
	header('location:index.php');
}
if(isset($_GET['delete'])){
	$user=$_GET['delete'];
	 $sqla="delete from sms where username='$user';";

	if($con->exec($sqla)){
		header('location:dashboard.php');
		}
	
	
}
if(isset($_GET['username'])){
	$user=$_GET['username'];
	$sql="select * from sms where username='$user'";
	$result=$con->query($sql);
	$row=$result->fetch(PDO::FETCH_ASSOC);
	if($result->rowcount()==1){
		$msg_name="Name : {$row['name']}<br>";
		$msg_father="Father : {$row['father']}<br>";
		$msg_date="Date : ".date('d/m/y');
		$vishnu=1;
	}
}
if(isset($_POST['mark1'])){
	$status=$_POST['attendence'];
	$username=$row['username'];
	$date=date('d/m/Y');
	$sql="insert into attendence(username,attendence_date,attendence_status) values('$username','$date','$status');";
	if($con->exec($sql)){
		echo "<br>attendence marked..!";
		echo "<br><a href='dashboard.php'>Home</a>";
		die();
	}
	else
	{
		echo "<br>only one time you can mark one each date";
		echo "<br><a href='dashboard.php'>Home</a>";
		die();
	}
}


	?>
<br>

<a href="dashboard.php">Home</a>
<a href="dashboard.php?logout=1">logout</a>
<br>

<?php
echo $msg_name;
echo $msg_father;
echo $msg_date;
if(isset($vishnu)){
?>
<form action="" method="post">
Present: <input type="radio" name="attendence" value="present" required>
absent: <input type="radio" name="attendence" value="absent"><br>
<input type="submit" value="mark attendence" name="mark1">
</form>
<?php
}
?>

<table style="text-align:center;">
	<tr>
		<th>Name</th>
		<th>Father</th>
		<th>Mobile</th>
		<th>Email</th>
		<th>Age</th>
		<th>Username</th>
		<th>Image</th>
		<th>Update Attendence</th>
		<th>Delete Data</th>
		
	</tr>
<?php while($row=$result->fetch(PDO::FETCH_ASSOC))
{
?>
	<tr>
		<td><?php echo $row['name']; ?></td>
		<td><?php echo $row['father']; ?></td>
		<td><?php echo $row['mobile']; ?></td>		
		<td><?php echo $row['email']; ?></td>
		<td><?php echo $row['age']; ?></td>
		<td><?php echo $row['username']; ?></td>	
		<td><img src="<?php echo "../upload/".$row['image']; ?>" style="width:50px; height:50px"></td>
		<td><a href="?username=<?php echo $row['username'];?>">Mark Attendence</td>
		
		<td><a href="?delete=<?php echo $row['username'];?>">Delete</td>
	</tr>
<?php	
}
?>
</table>
