<?php

require('../dbcon/dbcon.php');
session_start();
if(isset($_SESSION['name'])){
	header('location:dashboard.php');
}
$msg="";
if(isset($_POST['submit'])){
	$name=$_POST['uname'];
	$pass=$_POST['pass'];
$sql="select * from login where username='$name' and password='$pass'";
$result=$con->query($sql);
	if($result->rowcount()==1){
		$_SESSION['name']="admin";
		header('location:index.php');
	}
	else
	{
		$msg="please enter correct username or password";
	}
}?>
<html>
	<head>
		<title>Admin pannel</title>
	</head>
<body>
<a href="../">Home</a>
<center>
<form action="" method="post">

	username : <input type="text" name="uname"><br>
	password : <input type="password" name="pass"><br>
	<input type="submit" name="submit" value="login">
</form>
<?php echo $msg; ?>
</center>
</body>
</html>