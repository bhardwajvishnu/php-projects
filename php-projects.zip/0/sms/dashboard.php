<?php
require_once('dbcon/dbcon.php');
session_start();
if(!isset($_SESSION['name'])){
	header('location:index.php');
}
$msg="";
$a="N/A";

$sql="select * from sms where username='{$_SESSION['uname']}'";
$result=$con->query($sql);
$row=$result->fetch(PDO::FETCH_ASSOC);


if(isset($_POST['check_attendence'])){
	$date=$_POST['date'];
	$date=date("d-m-Y",strtotime($date));
	$date=str_replace('-','/',$date);
	$check="select * from attendence where username='{$_SESSION['uname']}' and attendence_date='$date'";
	//echo $check;
	$result_check=$con->query($check);
	$r=$result_check->fetch(PDO::FETCH_ASSOC);

	if(isset($r['attendence_status']))
		{
		$a=$r['attendence_status'];
		
		}
	else{
		$a="N/A";
	}
}

?>
<a href="dashboard.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="update.php?username=<?php echo $row['username']?>">Update Details</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="changepass.php?username=<?php echo $row['username']?>">Change password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href='logout.php'>Logout</a>
<table broder="1" width="50%">
<tr>
	<th colspan="2">Student Details</th>
</tr>
<tr>
	<td>Name</td>
	<td><?php echo $row['name'];?></td>
</tr>
<tr>
	<td>Father Name</td>
	<td><?php echo $row['father'];?></td>
</tr>
<tr>
	<td>Age </td>
	<td><?php echo $row['age'];?></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><?php echo $row['mobile'];?></td>
</tr>
<tr>
	<td>Email</td>
	<td><?php echo $row['email'];?></td>
</tr>
<tr>
	<td>image</td>
	<td><img src="<?php echo "upload/{$row['image']}"?>" style="width:50px; height:50px"></td>
</tr>
</table>
<hr>




<form action="" method="post">
<table broder="1" width="50%">
<?php 
	if(isset($result_check))
		{
			echo "<h2>your attendence status is : $a <h2>";
		}
		?>
<tr>
	<th colspan="2">Check Attendence</th>
</tr>
<tr>
	<td>Select Date</td>
	<td><input type="date" name="date" required></td>
</tr>
<tr>
	<td><input type="submit" name="check_attendence" value="check">
</tr>
</table>
<html>
<head>
</head>
<body>
</body>
</html>