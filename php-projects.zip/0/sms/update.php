<?php
require_once('dbcon/dbcon.php');
session_start();
if(!isset($_SESSION['name'])){
	header('location:index.php');
}
$username=$_GET['username'];

$sql="select * from sms where username='$username'";
$result=$con->query($sql);
$row=$result->fetch(PDO::FETCH_ASSOC);



$updated="";

if(isset($_POST['update'])){
	$name=$_POST['name'];
	$father=$_POST['fname'];
	$age=$_POST['age'];
	$mobile=$_POST['mob'];
	$email=$_POST['email'];
	$update="update sms set name='$name', father='$father', age='$age' , mobile='$mobile', email='$email' where username='$username'";
	if($result=$con->exec($update)){
		 $updated="<br>data has been updated</br>";
		 
		// header('location:update.php');
	}
	
}
?>

<a href="dashboard.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="update.php?username=<?php echo $row['username']?>">Update Details</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="changepass.php?username=<?php echo $row['username']?>">Change password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href='logout.php'>Logout</a>
<form action="" method="post">
<table broder="1" width="50%">
<tr>
	<th colspan="2">Student Details</th>
</tr>
<?php echo $updated; ?>
<tr>
	<td>Name</td>
	<td><input type="text" name="name" value="<?php echo $row['name'];?>"></td>
</tr>
<tr>
	<td>Father Name</td>
	<td><input type="text" name="fname" value="<?php echo $row['father'];?>"></td>
</tr>
<tr>
	<td>Age </td>
	<td><input type="text" name="age" value="<?php echo $row['age'];?>"></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><input type="text" name="mob" value="<?php echo $row['mobile'];?>"></td>
</tr>
<tr>
	<td>Email</td>
	<td><input type="text" name="email" value="<?php echo $row['email'];?>"></td>
</tr>
<tr>
	<td><input type="submit" name="update" value="update"></td>
</tr>
</table>
</form>
